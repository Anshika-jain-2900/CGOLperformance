
import java.util.Scanner;

	/**
	 * 
	 * Description : Code for Conway's game of life using multithreading 
	 * 
	 * @author Anshika Jain 
	 * 
	 * @version 1.0
	 *
	 */
	
	public class Mainline{

		public static void main(String[] args) {
			
			// Initializing values for rows and coloumns 
			int x, y;
			x=5;
			y=5;
			int i,j;

			//Array Declaration to store initial stage
			int[][] Array = new int[x][y];
			
			//The entries can be only 0 and 1 for dead cell and alive cell
			System.out.println("Enter 0 for dead cell and 1 for alive cell");
			System.out.println("Do not enter numbers except 0 and 1");
			
			// Taking input for Array
			System.out.println("Enter the initial state of CGOl: ");

			Scanner sc = new Scanner(System.in);
			
			//Taking the user input for the initial generation
			for (i=0; i<x; i++) 
			{
				for (j=0; j<y; j++) 
				{
					Array[i][j] = sc.nextInt();
				}
			}
					
			for(i=0;i<x;i++) 
			{
				for(j=0;j<y;j++) 
				{
					System.out.print(""+Array[i][j]);
				}
				System.out.println();
			}
			
			//Making the object of Logic class
		Mainlogic L = new Mainlogic(x,y,Array);
			
			//Execution of thread
			L.start();
			
			//Setting the priority so that it always run after printing the generation
			L.setPriority(2);
			
		}

	}


