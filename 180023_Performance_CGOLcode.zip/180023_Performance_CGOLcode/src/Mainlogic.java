
public class Mainlogic extends Thread {
	
	private int x, y;
	private int[][] Array;
	private int[][] futureCell = new int[100][100];

	public Mainlogic(int x, int y, int[][] Array) {
		this.x=x;
		this.y=y;
		this.Array = Array;
	}
	
	public void run() {
		
		//Calculating the time elapsed so far.
		long startTime = System.nanoTime();
		int i,j,k,l;

		// Loop through every cell of the every row and column
		for(i=1; i<x-1; i++)
		{
			for(j=1; j<y-1; j++)
			{

				// Finding alive cells
				int aliveCell = 0;
				for(k=-1; k<=1; k++)
					for(l=-1; l<=1; l++)
						aliveCell = aliveCell + Array[i+k][j+l];

				aliveCell = aliveCell - Array[i][j];

				// If cell is lonely then it dies
				if((Array[i][j] == 1) && (aliveCell < 2)){
					futureCell[i][j] = 0;
				}

				// If cell is overpopulated it dies
				else if((Array[i][j] == 1) && (aliveCell > 3)){
					futureCell[i][j] = 0;
				}

				// A new cell is born as 3 adjacent cells are alive
				else if((Array[i][j] == 0) && (aliveCell ==3)){
					futureCell[i][j] = 1;
				}

				// Nothing happens so it reMainlines same
				else{
					futureCell[i][j] = Array[i][j];
				}
			}
		}
		System.out.println();
		System.out.println("Next Generation: ");
		// Printing the next life
		for(k=0; k<x; k++)
		{
			for(l=0; l<y; l++)
			{
				System.out.print(futureCell[k][l] + " ");
			}
			System.out.println();
		}	
		//Assigning the next life to the Mainline array to print further generation
		for (k=0; k<x; k++) {
			for (l=0; l<y; l++) {
				Array[k][l] = futureCell[k][l];
			}
		}	
		// time to execute the next generation of CGOL
		long time = System.nanoTime() - startTime;
		System.out.println("");
        System.out.println("Time taken to creating Next Generation: " + time + " ns");
	}
}







